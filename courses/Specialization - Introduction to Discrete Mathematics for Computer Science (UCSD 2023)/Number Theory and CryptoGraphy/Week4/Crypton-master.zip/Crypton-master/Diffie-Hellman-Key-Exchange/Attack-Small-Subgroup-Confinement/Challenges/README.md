# Challenges

| S.No. | Challenge           | CTF                 | Year | Difficulty Level | Points |
|-------|:-------------------:|:-------------------:|:----:|:----------------:|:------:|
| 1     | Cryptopals Set-8 Challenge-57 | _None_ | _None_ | Medium           | _None_    |
