# Challenges

| S.No. | Challenge           | CTF                 | Year | Difficulty Level | Points |
|-------|:-------------------:|:-------------------:|:----:|:----------------:|:------:|
| 1     | Cryptopals Set-8 Challenge-59 | _None_ | _None_ | Medium           | _None_    |
| 2     | [EC-Cooldown](https://github.com/teambi0s/InCTFi/tree/master/2018/Crypto/EC-Cooldown) | InCTF International-2018 | 2018 | Medium | 1000 |
| 3     | [Secure Password DB](https://ctftime.org/task/8086) | SpamAndFlags Teaser 2019 | 2019 | Medium | 357 |
