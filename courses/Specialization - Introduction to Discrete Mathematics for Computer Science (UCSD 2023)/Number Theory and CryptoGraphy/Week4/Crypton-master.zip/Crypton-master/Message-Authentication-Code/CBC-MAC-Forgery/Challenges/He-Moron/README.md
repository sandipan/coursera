# He Moron

**Description**: An overconfident boastful moron has claimed that he has written his own version of a MAC and has challenged the people here at Xiomara to break it! We are very certain that he might have made a mistake in the implementation. So, help us find one, crack his scheme and get the flag!  
  
**Challenge points**: 250  
  
**Files**:
1. server.py: Code running on the server
2. source: Source code given
  

**Writeup**:
