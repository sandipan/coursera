# Challenges

| S.No. | Challenge           | CTF                 | Year | Difficulty Level | Points |
|-------|:-------------------:|:-------------------:|:----:|:----------------:|:------:|
| 1     |[EC-Auth](EC-Auth/)  | InCTF International | 2018 | Medium           | 999    |
