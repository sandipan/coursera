# Challenges

| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1     | [Gracias](Gracias/)                                                  | ASIS Finals              | 2017 | _None_           |  287   |