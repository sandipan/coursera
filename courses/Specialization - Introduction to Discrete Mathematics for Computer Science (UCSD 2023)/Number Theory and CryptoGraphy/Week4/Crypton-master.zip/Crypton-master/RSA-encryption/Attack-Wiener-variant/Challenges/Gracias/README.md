# Gracias

1. Challenge Description: Some people think that combination of cryptographic systems will definitely improve the security. That’s your turn to prove them wrong.
2. Challenge Writeups:
   + [My writeup](https://masterpessimistaa.wordpress.com/2017/11/24/asis-finals-ctf-2017-gracias-writeup/)

## Directory Contents
1. [gracias.py](gracias.py)- encryption.py
2. [enc_pubkey.txt](enc_pubkey.txt)- ciphertext and public key file