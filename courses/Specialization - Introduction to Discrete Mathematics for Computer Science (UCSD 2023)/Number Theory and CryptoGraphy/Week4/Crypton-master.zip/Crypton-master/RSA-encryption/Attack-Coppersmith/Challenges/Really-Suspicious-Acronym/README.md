# Really Suspicious Acronym

1. **Challenge Description**: You can't break my public key if you don't know it, amirite?
2. **Challenge write-ups**:
   + [by s0rc3r3r](https://ctftime.org/writeup/13941)

## Directory Contents
1. [task.sage](task.sage) - challenge encryption script
2. [output.txt](output.txt) - output file; includes public key, ciphertext etc.
3. [exploit.sage](exploit.sage) - solution script, written in sage
