# Stereotypes

1. Challenge Description: Welcome to BackdoorCTF17. Just one advice Never ignore the challenge names, they provides the maximum hint. Okay now let's leave the boring stuff apart i know you are eagerly waiting to gain some points So here it is : XXXXXXXXXXXXXXX
2. Challenge writeups:
   + [by blue](https://ctftime.org/writeup/7654)

## Directory Contents
1. [ciphertext](ciphertext)- ciphertext file
2. [plaintext.txt](plaintext.txt)- plaintext file
3. [pubkey.txt](pubkey.txt)- public key