# Challenges


| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1     | [Stereotypes](stereotypes/)                                          | Backdoor                 | 2017 | _None_           |        |
| 2     | [Bazik](https://ctftime.org/task/6293)                               | Meepwn-Quals             | 2018 | _None_           | 100    |
| 3     | [Really Suspicious Acronym](Really-Suspicious-Acronym/) | CONFidence CTF Teaser | 2019 | _None_ | 99 |
