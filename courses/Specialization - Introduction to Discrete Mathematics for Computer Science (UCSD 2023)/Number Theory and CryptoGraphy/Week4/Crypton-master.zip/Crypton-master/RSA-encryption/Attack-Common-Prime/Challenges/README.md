# Challenges
  

| S.No. | Challenge                                         | CTF     | Year | Difficulty Level | Points |
|-------|:-------------------------------------------------:|:-------:|:----:|:----------------:|:------:|
| 1     | [Challenge-3](../../Intro-Challenges/Challenge-3/)| _None_  |      | 2                | 20     |