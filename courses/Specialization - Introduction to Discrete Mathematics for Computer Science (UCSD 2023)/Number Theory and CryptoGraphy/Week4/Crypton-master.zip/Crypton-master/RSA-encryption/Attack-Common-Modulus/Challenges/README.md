# Challenges
  

| S.No. | Challenge                                         | CTF           | Year | Difficulty Level | Points |
|-------|:-------------------------------------------------:|:-------------:|:----:|:----------------:|:------:|
|1      | [RSA-1s-Fun](RSA-1s-Fun/)                         | InCTF         | 2017 | _None_           | 150    |