# QProximity
  
1. Challenge Description: _None_
2. Writeups: 
   * [By the challenge author](https://grocid.net/2017/09/16/finding-close-prime-factorizations/)
   * [Other writeups](https://ctftime.org/writeup/7463)
  

## Directory Contents
1. [public](public)- public key file
2. [secret.enc](secret.enc)- ciphertext file