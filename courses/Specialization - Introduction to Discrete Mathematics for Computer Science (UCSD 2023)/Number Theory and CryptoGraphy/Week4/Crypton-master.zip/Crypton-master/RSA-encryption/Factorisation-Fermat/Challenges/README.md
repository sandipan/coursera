# Challenges

| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1      | [Easy-RSA-2](Easy-RSA-2/)| ISITDTU CTF Quals | 2019 | _None_ | 919 |
| 2     | [QProximity](qproximity/)                                            | SEC-T CTF                | 2017 | _None_           | 200    |
| 3     | [Crafted-RSA](Crafted-RSA/)                                          | InCTF                    | 2017 | _None_           | 150    |
