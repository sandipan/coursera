# Easy RSA 2

1. **Challenge Description**: Let's continue with RSA
2. **Writeups**:
   + [Unintended solution - Fermat's Factorisation](https://ctftime.org/task/8848)

## Directory Contents
1. [task.py](task.py): Given task file
