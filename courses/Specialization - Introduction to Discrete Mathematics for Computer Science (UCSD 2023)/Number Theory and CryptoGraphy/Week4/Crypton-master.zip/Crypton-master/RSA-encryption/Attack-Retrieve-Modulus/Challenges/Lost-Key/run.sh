#!/bin/sh
python rsa.py
