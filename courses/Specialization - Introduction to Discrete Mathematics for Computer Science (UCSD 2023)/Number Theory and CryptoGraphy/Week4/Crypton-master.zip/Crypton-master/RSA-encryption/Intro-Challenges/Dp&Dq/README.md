# Dp&Dq
  
**Level**: 4
  
**Description**: No need!
  
**Points**: 40
  
**Documentation reference for libraries used**:
1. pycrypto: https://www.dlitz.net/software/pycrypto/api/2.6/
2. gmpy2: https://gmpy2.readthedocs.io/en/latest/
