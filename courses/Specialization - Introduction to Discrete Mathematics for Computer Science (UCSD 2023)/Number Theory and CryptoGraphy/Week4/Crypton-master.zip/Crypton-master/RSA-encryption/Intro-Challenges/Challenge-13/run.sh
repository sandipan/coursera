#!/bin/sh
python encrypt.py
