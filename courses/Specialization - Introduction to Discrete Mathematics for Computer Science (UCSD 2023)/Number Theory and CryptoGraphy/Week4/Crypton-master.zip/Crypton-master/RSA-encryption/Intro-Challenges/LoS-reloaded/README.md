# Labyrinth of Suffering reloaded
  
**Level**: 5
  
**Description**: "What is the best way to go about being a person? What are the rules of this game, and how might we best play it?"  
"Damn it! How will I ever get out of this labyrinth of suffering??" - Looking for Alaska by John Green. Getting out isn't easy, really.  
"You live for pretentious metaphors" - Moby Dick
  
**Points**: 60
  
**References**: Symbolism, Imagery and Allegory