# Welcome

**Level**: 1  

**Description**: Do whatever you want, just get me the flag!  
  
**Points**: 5  
  

**Documentation reference for libraries used**:
1. gmpy2: https://gmpy2.readthedocs.io/en/latest/
2. pycrypto: https://www.dlitz.net/software/pycrypto/api/2.6/
3. pycrypto's PublicKey RSA module: https://www.dlitz.net/software/pycrypto/api/2.6/toc-Crypto.PublicKey.RSA-module.html