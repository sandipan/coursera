# Challenge-1

**Level**: 1  
  
**Description**: You are given ciphertext of a message that is encrypted using `encrypt.py` and stored in `ciphertext.txt`. Also, private key values are stored in `privatekey.txt`. Get the flag and score some points!
  
**Points**: 10  
  

**Documentation reference for libraries used**:
1. pycrypto: https://www.dlitz.net/software/pycrypto/api/2.6/
2. [OPTIONAL] gmpy2: https://gmpy2.readthedocs.io/en/latest/