# Challenge-4 Reloaded
  
**Level**: 3  
  
**Description**: Hope you solved challenge-4 and enjoyed it! This time too, we have the same vulnerability, just added some randomisation to make things a bit more difficult!  
  
**Points**: 35  
  

**Documentation reference for libraries used**:
1. gmpy2: https://gmpy2.readthedocs.io/en/latest/
2. pycrypto: https://www.dlitz.net/software/pycrypto/api/2.6/
3. pycrypto's PublicKey RSA module: https://www.dlitz.net/software/pycrypto/api/2.6/toc-Crypto.PublicKey.RSA-module.html