# Multi Layer RSA

1. Challenge Description: Adding Layers to encryption doesn't always help!
2. Challenge Writeups: 
   + [My writeup](https://amritabi0s.wordpress.com/2017/12/18/inctf-2017-multi-layer-rsa-writeup/)

## Directory Contents
1. [ciphertext.txt](ciphertext.txt)- Ciphertext file
2. [modulus.txt](modulus.txt)- Public key file
3. [Multi_LayerRSAencrypt.py](Multi_LayerRSAencrypt.py)- Encryption file