# Multicast

1. Challenge Description: Many messages intercepted. Break them.  
2. Challenge Writeups:
   + [My writeup](https://github.com/ashutosh1206/Crypto-CTF-Writeups/tree/master/2017/Plaid-CTF/Multicast)
   + [Other writeups](https://ctftime.org/task/3999)

## Directory Contents
1. [data.txt](data.txt)- output file
2. [generate.sage](generate.sage)- encryption script