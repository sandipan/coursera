# Challenges
  

| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1     | [Multicast](Multicast/)                                              | Plaid                    | 2017 | _None_           | 175    |