# Challenges
  

| S.No. | Challenge                                                            | CTF        | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:----------:|:----:|:----------------:|:------:|
| 1     | [Cryptopals Challenge-26](http://cryptopals.com/sets/4/challenges/26)| _None_     |_None_| _None_           | _None_ |
  

Cryptopals Challenge-26 exploit script: [exploit.py](https://github.com/ashutosh1206/Matasano-Crypto-Challenges/blob/master/set4/p26/exploit.py)