# Challenges
  
| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1     | [Secret-Server](Secret-Server/)                                      | HITCON Quals             | 2017 | _None_           | 221    |