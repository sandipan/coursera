# BabyCrypt

1. Challenge Description:  [https://ctftime.org/task/4662](https://ctftime.org/task/4662)
2. Writeups: 
   * [My writeup](https://github.com/ashutosh1206/Crypto-CTF-Writeups/tree/master/2017/CSAW-CTF-Quals/BabyCrypt)
   * [Other writeups](https://ctftime.org/task/4662)