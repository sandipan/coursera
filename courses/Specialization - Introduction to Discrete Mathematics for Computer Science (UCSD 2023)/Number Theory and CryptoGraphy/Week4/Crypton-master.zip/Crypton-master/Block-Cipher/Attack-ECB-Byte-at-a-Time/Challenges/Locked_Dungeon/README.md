# Locked Dungeons
  
1. Challenge Description: [https://ctftime.org/task/5679](https://ctftime.org/task/5679)
2. Writeups: [https://ctftime.org/task/5679](https://ctftime.org/task/5679)