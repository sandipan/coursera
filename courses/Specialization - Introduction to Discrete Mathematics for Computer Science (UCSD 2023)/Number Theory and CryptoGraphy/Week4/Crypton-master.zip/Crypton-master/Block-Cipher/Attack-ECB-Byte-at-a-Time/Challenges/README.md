# Challenges
  

| S.No. | Challenge                                                            | CTF        | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:----------:|:----:|:----------------:|:------:|
| 1     | [Cryptopals Challenge-12](http://cryptopals.com/sets/2/challenges/12)| _None_     |_None_|   _None_         | _None_ |
| 2     | [Baby-Crypt](Baby-Crypt/)                                            | CSAW-Quals | 2017 |   _None_         | 350    | 
| 3     | [Locked Dungeons](Locked_Dungeon/)                                   | Swamp-CTF  | 2018 |   _None_         | 481    |