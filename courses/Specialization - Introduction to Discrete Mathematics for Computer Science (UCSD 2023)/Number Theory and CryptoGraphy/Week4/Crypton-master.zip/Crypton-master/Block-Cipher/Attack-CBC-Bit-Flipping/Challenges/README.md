# Challenges


| S.No. | Challenge                                                            | CTF                      | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:------------------------:|:----:|:----------------:|:------:|
| 1     | [Cryptopals Challenge-16](http://cryptopals.com/sets/2/challenges/16)| _None_                   |_None_|     _None_       | _None_ |
| 2     | [Secret-Server](Secret-Server/)                                      | HITCON Quals             | 2017 |     _None_       | 221    |
| 3     | [CNVService](CNVService/)                                            | AceBear Security Contest | 2018 |     _None_       | 856    |
| 4     | [USSH 3.0](https://ctftime.org/task/6311) | CTFZone CTF Quals | 2018 | _None_ | 138 |
| 5     | [Into The Darkness](https://ctftime.org/task/6580) | HackIT CTF | 2018 | _None_ | 862 |
| 6     | [level-21](http://websec.fr/level21) | websec.fr | Wargame | medium | 3 |  
