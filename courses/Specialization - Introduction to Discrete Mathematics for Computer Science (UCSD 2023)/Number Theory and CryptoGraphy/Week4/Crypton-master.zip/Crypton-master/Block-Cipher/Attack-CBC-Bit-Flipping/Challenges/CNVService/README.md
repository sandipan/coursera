# CNVService
  
1. Challenge Description: [https://ctftime.org/task/5212](https://ctftime.org/task/5212)
2. Writeups: [My writeup](https://masterpessimistaa.wordpress.com/2018/01/31/cnvservice-acebear-ctf-2018-writeup/)
