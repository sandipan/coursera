# CBC Bit Flipping Attack

You can read about this attack in detail on my blog [here](https://masterpessimistaa.wordpress.com/2017/05/03/cbc-bit-flipping-attack/) 