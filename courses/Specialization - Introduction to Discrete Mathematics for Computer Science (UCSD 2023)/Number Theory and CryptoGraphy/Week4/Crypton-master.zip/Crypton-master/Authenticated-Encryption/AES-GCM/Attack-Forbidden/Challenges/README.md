# Challenges
  

| S.No. | Challenge                                                            | CTF             | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:---------------:|:----:|:----------------:|:------:|
| 1     | [Forbidden](Forbidden/)                                              | Volga CTF Quals | 2018 | _None_           | 300    | 