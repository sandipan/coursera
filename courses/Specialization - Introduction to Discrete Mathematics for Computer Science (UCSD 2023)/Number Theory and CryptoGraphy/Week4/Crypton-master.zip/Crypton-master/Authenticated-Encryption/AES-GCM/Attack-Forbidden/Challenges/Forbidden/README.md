# Forbidden

1. Challenge Description: Our friend tried to send us all his BTCs, but MAC of the transaction was lost. We need your help to compute MAC for this encrypted transaction. Send it in format VolgaCTF{AuthTag_in_HEX}.
2. Writeups: [Writeup by team RedRocket](http://blog.redrocket.club/2018/03/27/VolgaCTF-Forbidden/)

## Directory Contents
1. [task.py](task.py) - given encryption script
2. [known](known) - given ciphertext, authtag pairs