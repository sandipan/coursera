# Challenges


| S.No. | Challenge                                                            | CTF            | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:--------------:|:----:|:----------------:|:------:|
| 1     | [Multiplayer Part-1](Multiplayer-1/)                                 | Hack.lu        | 2018 | _None_           | 268    |
| 2     | [Multiplayer Part-2](Multiplayer-2/)                                 | Hack.lu        | 2018 | _None_           |        |
