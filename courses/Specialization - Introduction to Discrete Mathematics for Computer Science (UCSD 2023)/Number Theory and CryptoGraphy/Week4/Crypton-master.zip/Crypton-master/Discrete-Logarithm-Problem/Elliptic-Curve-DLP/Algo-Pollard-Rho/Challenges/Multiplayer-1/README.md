# Multiplayer-1

1. Challenge Description: [https://ctftime.org/task/6860](https://ctftime.org/task/6860)
2. Writeups:
   + [My writeup](https://ctftime.org/writeup/11832)

## Directory Contents
1. [server.sage](server.sage)- given encryption script
2. [parameters.sage](parameters.sage) - File containing public EC parameters required for hosting the challenge locally
3. [points.db](points.db) - database essential for challenge hosting
