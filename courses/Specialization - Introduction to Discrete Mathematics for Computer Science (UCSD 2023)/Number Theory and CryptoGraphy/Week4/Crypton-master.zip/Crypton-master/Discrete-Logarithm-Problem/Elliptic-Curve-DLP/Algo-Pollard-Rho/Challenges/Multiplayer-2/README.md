# Multiplayer-2

1. Challenge Description: [N/A]()
2. Writeups:
   + [N/A]()

## Directory Contents
1. [server.sage](server.sage)- given encryption script
2. [parameters.sage](parameters.sage) - File containing public EC parameters required for hosting the challenge locally
3. [points.db](points.db) - database essential for challenge hosting
