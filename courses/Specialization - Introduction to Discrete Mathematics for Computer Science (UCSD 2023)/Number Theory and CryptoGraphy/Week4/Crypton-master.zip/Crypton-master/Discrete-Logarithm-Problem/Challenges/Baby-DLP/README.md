# Baby-DLP
  
1. Challenge Description: [https://ctftime.org/task/4541](https://ctftime.org/task/4541)
2. Writeups:
   * [My writeup](https://github.com/ashutosh1206/Crypto-CTF-Writeups/tree/master/2017/Tokyo-Westerns-CTF/baby-dlp)
   * [Other writeups](https://ctftime.org/task/4541)