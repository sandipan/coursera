#!/bin/sh

python server.py