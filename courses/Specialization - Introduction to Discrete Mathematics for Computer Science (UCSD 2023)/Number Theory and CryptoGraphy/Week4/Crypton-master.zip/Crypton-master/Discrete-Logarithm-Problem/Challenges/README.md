# Challenges
  

| S.No. | Challenge                                                            | CTF            | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:--------------:|:----:|:----------------:|:------:|
| 1     | [DLP](DLP/)                                                          | ASIS Quals     | 2017 | _None_           | 158    |
| 2     | [Baby-DLP](Baby-DLP/)                                                | Tokyo-Westerns | 2017 | _None_           | 91     |
| 3     | [Madlog](https://ctftime.org/task/4617)                              | SEC-T CTF      | 2017 | _None_           | 200    |