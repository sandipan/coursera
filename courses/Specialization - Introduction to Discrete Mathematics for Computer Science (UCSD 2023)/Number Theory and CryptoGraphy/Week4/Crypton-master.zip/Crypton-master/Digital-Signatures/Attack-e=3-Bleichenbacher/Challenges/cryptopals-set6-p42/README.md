# Bleichenbacher's e=3 RSA Attack
  
**Description**:  
  
**Points**: _None_   
  
**Writeup**: [My exploit script](https://github.com/ashutosh1206/Matasano-Crypto-Challenges/tree/master/set6/p42)