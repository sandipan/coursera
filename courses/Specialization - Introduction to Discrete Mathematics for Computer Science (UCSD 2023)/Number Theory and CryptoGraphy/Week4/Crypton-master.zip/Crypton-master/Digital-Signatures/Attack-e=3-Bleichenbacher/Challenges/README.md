# Challenges
  

| S.No. | Challenge                                                                   | CTF              | Year    | Difficulty Level | Points |
|-------|:---------------------------------------------------------------------------:|:----------------:|:-------:|:----------------:|:------:|
|1      | [Cryptopals Set-6 Challenge-42](http://cryptopals.com/sets/6/challenges/42) | _None_           | _None_  | _None_           | _None_ |
|2      | [RSA CTF Challenge](https://ctftime.org/task/4233)                          | Google CTF Quals | 2017    | Medium           | _None_ |