# Nonsense
  
1. Challenge Description: We've intercepted several consecutive signatures. Take everything you need and find the secret key. Send it to us in hex.
2. Writeups: 
   * [My writeup](https://github.com/ashutosh1206/Crypto-CTF-Writeups/tree/master/2018/VolgaCTF-Quals/Nonsense)
   * [Other writeups](https://ctftime.org/task/5610)
  

## Directory Contents
1. [encrypt.py](encrypt.py) - given encryption script
2. [signatures](signatures) - file containing all the signatures generated