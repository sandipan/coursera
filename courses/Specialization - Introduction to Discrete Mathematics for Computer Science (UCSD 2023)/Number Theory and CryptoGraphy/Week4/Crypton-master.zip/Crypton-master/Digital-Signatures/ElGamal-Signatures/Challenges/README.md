# Challenges
  

| S.No. | Challenge                                                            | CTF        | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:----------:|:----:|:----------------:|:------:|
| 1     | [Nonsense](Nonsense/)                                                | Volga-Quals| 2018 | _None_           | 200    |
