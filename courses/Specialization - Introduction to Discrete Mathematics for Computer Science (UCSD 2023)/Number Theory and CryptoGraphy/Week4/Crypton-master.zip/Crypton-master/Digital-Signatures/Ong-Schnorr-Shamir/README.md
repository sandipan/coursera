# Ong-Schnorr-Shamir Signature Scheme

