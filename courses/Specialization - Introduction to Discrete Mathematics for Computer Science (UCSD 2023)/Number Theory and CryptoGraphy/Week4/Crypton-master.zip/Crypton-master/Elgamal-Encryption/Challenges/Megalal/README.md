# Megalal
  
1. Challenge Description: You can reach a strange authentication system here: nc 35.197.255.108 1337. I'm sure you know what you have to do.
2. Writeups: [https://ctftime.org/task/5145](https://ctftime.org/task/5145)

## Directory Contents
1. [megalal.py](megalal.py) - given encryption script