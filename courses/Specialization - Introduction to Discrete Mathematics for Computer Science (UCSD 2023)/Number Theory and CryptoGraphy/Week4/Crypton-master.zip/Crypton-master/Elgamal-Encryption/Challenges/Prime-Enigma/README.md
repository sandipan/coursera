# Prime Enigma
  
1. Challenge Description: Hey there fellow lizard how nice of you to drop by! Did you know those filthy humans really think that some numbers have special meanings? Seven, 13 and for some strange reason even 9000. Go and show them that a good prime does not make a secure cryptosystem!
2. Writeups: 
   * [My writeup](https://github.com/ashutosh1206/Crypto-CTF-Writeups/tree/master/2017/Hack.lu-CTF/prime-enigma)
   * [Other writeups](https://ctftime.org/task/4770)

## Directory Contents
1. [encrypt.py](encrypt.py) - given encryption script
2. [ciphertext.txt](ciphertext.txt) - ciphertext file