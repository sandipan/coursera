# Challenges
  

| S.No. | Challenge                                                            | CTF         | Year | Difficulty Level | Points |
|-------|:--------------------------------------------------------------------:|:-----------:|:----:|:----------------:|:------:|
| 1     | [Prime-Enigma](Prime-Enigma/)                                        | Hack.lu CTF | 2017 | _None_           | 150    |
| 2     | [Megalal](Megalal/)                                                  | 34c3 Junior | 2017 | _None_           | 188    |